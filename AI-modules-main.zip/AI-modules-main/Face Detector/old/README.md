# Webcam Face Detection Using JavaScript, PHP, and MySQL

View Step-by-Step Tutorial: https://www.edopedia.com/blog/webcam-face-detection-javascript-php-mysql/
