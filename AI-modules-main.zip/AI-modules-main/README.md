# AI-modules
face detection, face data, face similarity comparison

used AWS JavaScript API

no need php server for running 
